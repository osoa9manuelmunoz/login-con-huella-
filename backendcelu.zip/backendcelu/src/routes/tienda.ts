import { Router } from "express";
import jwt from "jsonwebtoken";
import {Conn} from "../db/conn.js";
import bcrypt from "bcryptjs";
import { RowDataPacket } from "mysql2";
import { crossOriginResourcePolicy } from "helmet";
import fs from "fs";
import path from "path";

export default class product {
    router: Router;
    constructor() {
      this.router = Router();
      this.routes();
    }
  
    routes() {
        this.router.get("/", async (req, res) => {
            const token = req.headers.authorization.split(' ')[1];
            console.log(token)
            const secret = process.env.SECRET ?? 'de88caa0342d089047adc90825f2ee06f6a33d1f9c28c98505f59022cbfb52dd';
            if (!token) {
              return res.status(403).send("token");
            }
            try {
                const decoded = jwt.verify(token, secret);
                console.log(decoded)
                if (decoded) {
                    // Cargar el archivo JSON
                    const productsPath = path.resolve("D:/flutter projects/backendcelu/src/db/products.json");
                    console.log(productsPath)
                    const rawData = fs.readFileSync(productsPath);
                    const productsString = rawData.toString(); 
                    const products = JSON.parse(productsString);
                    res.send(products)
                }
            } catch (error) {
                res.status(500).send("Invalid token");
            }
        });
    }
}
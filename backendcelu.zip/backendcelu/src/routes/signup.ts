import { Router } from "express";
import { Conn } from "../db/conn.js";
import bcrypt from "bcryptjs";
import { RowDataPacket } from "mysql2";

export default class Signup {
  router: Router;
  constructor() {
    this.router = Router();
    this.routes();
  }

  routes() {
    this.router.post("/", async (req, res) => {
      const { username, password } = req.body;
      const connection = await Conn();
      try {
        const [rows] = await connection.query<RowDataPacket[]>(`SELECT * FROM users WHERE username = ?`, [username]);
        console.log(rows);
        if (rows.length !== 0) {
          console.log('Email already exists')
          return('Email already exists')
        }
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        await connection.query(`INSERT INTO users (username, password) VALUES (?, ?)`, [username, hashedPassword]);
        res.send("User created");
      } catch (error) {
        res.status(500).send(error);
      }
    });
  }
}
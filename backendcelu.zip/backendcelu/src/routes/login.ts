import { Router } from "express";
import jwt from "jsonwebtoken";
import {Conn} from "../db/conn.js";
import bcrypt from "bcryptjs";
import { RowDataPacket } from "mysql2";
import { crossOriginResourcePolicy } from "helmet";

export default class Login {
  router: Router;
  constructor() {
    this.router = Router();
    this.routes();
  }

  routes() {
    this.router.post("/", async (req, res) => {
      const { username, password } = req.body;
      const secret = process.env.SECRET ?? 'de88caa0342d089047adc90825f2ee06f6a33d1f9c28c98505f59022cbfb52dd';
      const connection = await Conn();
      try{
        const [rows] = await connection.query<RowDataPacket[]>(`SELECT * FROM users WHERE username = ?`, [username]);
        if (rows.length === 0) {
          return res.status(404).send("Invalid username or password");
        } else{
          console.log(rows)
          for (const row of rows) {
            if(typeof row.password !== "undefined"){
              const isMatch = await bcrypt.compare(password, row.password);
              if (isMatch) {
                const id = row.id;
                const token = jwt.sign({ username, id, exp: Math.floor(Date.now() / 1000) + (60 * 60) }, secret);
              res.send(token)}
              else res.status(404).send("Invalid username or ");
            }
          }
        }
      } catch (error) {
        res.status(500).send
      }
    });

    this.router.post("/biometricLogin", async (req, res) => {
      const { username, password } = req.body;
      const secret = process.env.SECRET ?? 'de88caa0342d089047adc90825f2ee06f6a33d1f9c28c98505f59022cbfb52dd';
      const connection = await Conn();
      try{
        const [rows] = await connection.query<RowDataPacket[]>(`SELECT * FROM users WHERE username = ?`, [username]);
        if (rows.length === 0) {
          return res.status(404).send("Invalid username or password");
        } else{
          console.log(rows)
          for (const row of rows) {
            if(typeof row.password !== "undefined"){
              const isMatch = await bcrypt.compare(password, row.password);
              if (isMatch) {
                const id = row.id;
                const token = jwt.sign({ username, id, exp: Math.floor(Date.now() / 1000) + (7 * 24 * 60 * 60) }, secret);
              res.send(token)}
              else res.status(404).send("Invalid username or password");
            }
          }
        }
      } catch (error) {
        res.status(500).send
      }
    });

    this.router.get("/verify", async (req, res) => {
      const token = req.headers.authorization;
      console.log(token)
      const secret = process.env.SECRET ?? 'de88caa0342d089047adc90825f2ee06f6a33d1f9c28c98505f59022cbfb52dd';
      if (!token) {
        return res.status(403).send("A token is required for authentication");
      }
      try {
        const decoded = jwt.verify(token, secret);
        if (decoded) {
          const id = decoded['id'];
          const username = decoded['username'];
          const t = jwt.sign({ username, id, exp: Math.floor(Date.now() / 1000) + (60 * 60) }, secret);
          res.send(t);
        }
      } catch (error) {
        res.status(500).send("Invalid token");
      }
  });
  }
}
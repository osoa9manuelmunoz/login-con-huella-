import {createPool} from 'mysql2/promise'

export async function Conn() {
    const connection = await createPool({
        host: 'localhost',
        user: 'root',
        password: 'Manuel112003',
        database: 'login'
    })
    return connection
}